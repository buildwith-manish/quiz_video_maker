# quiz-video-maker

Makes full quiz videos (50 questions in one go) from a list of questions.
Currently included: **Spot the Odd One**.

## First time (in a GitHub Codespace)
    bash setup.sh

## Make a video
    npm run questions     # builds questions.json (50 questions, seed 1)
    npm run render        # renders video.mp4 (about 11 min on 2 CPUs)

New set of questions: `node gen_questions.js 50 2` (change the last number).
Then download video.mp4 from the file list (right-click > Download).

## Edit
- pairs.json: emoji pairs.  questions.json: per-question control.  scene.html: the look.
