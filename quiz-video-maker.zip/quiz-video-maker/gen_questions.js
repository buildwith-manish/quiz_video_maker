// node gen_questions.js [count=50] [seed=1]  ->  questions.json
// Auto-builds a difficulty curve: easy pairs/small grid/long timer first, hard pairs/big grid/short timer last.
const fs=require('fs');
const N=+process.argv[2]||50, seed0=+process.argv[3]||1;
const pairs=JSON.parse(fs.readFileSync(__dirname+'/pairs.json','utf8'));
let s=seed0;const rnd=()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const pick=a=>a[Math.floor(rnd()*a.length)];
const recent=[];const qs=[];
for(let i=0;i<N;i++){
  const p=N>1?i/(N-1):0;
  const lv=p<.25?[1,2]:p<.6?[2,3]:[3];
  let pool=pairs.filter(x=>lv.includes(x.level)&&!recent.includes(x));
  if(!pool.length)pool=pairs.filter(x=>lv.includes(x.level));
  const pr=pick(pool);recent.push(pr);if(recent.length>Math.min(8,pairs.filter(x=>lv.includes(x.level)).length-1))recent.shift();
  const [cols,rows]=p<.2?[5,3]:p<.45?[7,4]:p<.75?[8,4]:[9,4];
  const time=p<.3?6:p<.7?5:4;
  const flip=rnd()<0.2&&pr.level>1; // sometimes swap which emoji is the odd one
  qs.push({n:i+1,total:N,base:flip?pr.odd:pr.base,odd:flip?pr.base:pr.odd,cols,rows,pos:Math.floor(rnd()*cols*rows),time,hint:time>=5,outro:i===N-1});
}
fs.writeFileSync('questions.json',JSON.stringify(qs,null,1));
console.log('wrote questions.json with',N,'questions');
