#!/usr/bin/env bash
# One-time setup for GitHub Codespaces (Ubuntu/Debian). Run: bash setup.sh
set -e
sudo apt-get update
sudo apt-get install -y ffmpeg fonts-noto-color-emoji
mkdir -p ~/.fonts
curl -L -o ~/.fonts/Poppins-BoldItalic.ttf https://github.com/google/fonts/raw/main/ofl/poppins/Poppins-BoldItalic.ttf
fc-cache -f
npm install
npx playwright install --with-deps chromium
echo "Setup done. Now run:  npm run questions && npm run render"
