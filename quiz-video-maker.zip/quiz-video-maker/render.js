// node render.js [questions.json=questions.json] [out.mp4=odd_one_out.mp4] [workers=2]
const {chromium}=require('playwright');
const {spawn,execFileSync}=require('child_process');
const fs=require('fs'),path=require('path'),os=require('os');
const [qf='questions.json',out='odd_one_out.mp4',W0]=process.argv.slice(2);
const questions=JSON.parse(fs.readFileSync(qf,'utf8'));
const workers=+W0||Math.min(2,os.cpus().length);
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'odd-'));
const SR=44100,FPS=30;

/* ---- tiny sound synth (no python/numpy needed) ---- */
const sine=(f,d,g)=>{const n=Math.floor(d*SR),o=new Float32Array(n);let ph=0;for(let i=0;i<n;i++){const fr=g?f+(g-f)*i/n:f;ph+=2*Math.PI*fr/SR;o[i]=Math.sin(ph)}return o};
const envl=(a,d,att=.003)=>{const n=a.length;for(let i=0;i<n;i++){const t=i/SR;a[i]*=Math.min(1,t/att)*Math.exp(-t/(d/4))}return a};
const scale=(a,k)=>{for(let i=0;i<a.length;i++)a[i]*=k;return a};
function sfx(ev){
  switch(ev.type){
    case'tick':return scale(envl(sine(1300,.05),.05),.35);
    case'urgent':return scale(envl(sine(1900,.09),.09),.5);
    case'pop':return scale(envl(sine(450,.14,900),.14),.5);
    case'whoosh':{const n=Math.floor(.6*SR),x=new Float32Array(n);let acc=0;for(let i=0;i<n;i++){acc=acc*.96+(Math.random()*2-1)*.5;x[i]=acc*Math.pow(Math.sin(Math.PI*i/n),2)*1.4}return x}
    case'ding':{const d=1.6,mix=new Float32Array(Math.floor(d*SR));[[784,.5],[1175,.35],[1568,.3],[2349,.15]].forEach(([f,a])=>{const s=sine(f,d);for(let i=0;i<s.length;i++)mix[i]+=a*s[i]});return scale(envl(mix,d,.004),.5)}
  }return new Float32Array(0)}
function wav(events,dur,file){
  const N=Math.floor((dur+.2)*SR),o=new Float32Array(N);
  for(const e of events){const w=sfx(e),i0=Math.floor(e.t*SR);for(let i=0;i<w.length&&i0+i<N;i++)o[i0+i]+=w[i]}
  let m=0;for(const v of o)m=Math.max(m,Math.abs(v));const k=m>0?.85/Math.max(1,m):1;
  const b=Buffer.alloc(44+N*2);b.write('RIFF',0);b.writeUInt32LE(36+N*2,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(SR,24);b.writeUInt32LE(SR*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(N*2,40);
  for(let i=0;i<N;i++)b.writeInt16LE(Math.max(-32767,Math.min(32767,Math.round(o[i]*k*32767))),44+i*2);
  fs.writeFileSync(file,b)}

/* ---- render one question -> segment mp4 ---- */
async function renderOne(page,q){
  const seg=path.join(tmp,`seg_${String(q.n).padStart(3,'0')}.mp4`);
  const info=await page.evaluate(q=>{const s=init(q);window.__s=s;return{dur:s.dur,events:s.events}},q);
  const wf=seg.replace('.mp4','.wav');wav(info.events,info.dur,wf);
  const n=Math.round(info.dur*FPS);
  const ff=spawn('ffmpeg',['-v','error','-y','-f','image2pipe','-framerate',String(FPS),'-c:v','mjpeg','-i','-','-i',wf,'-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-r',String(FPS),'-c:a','aac','-ar','44100','-ac','1','-b:a','128k','-t',String(n/FPS),seg],{stdio:['pipe','inherit','inherit']});
  const done=new Promise(r=>ff.on('close',r));
  for(let i=0;i<n;i++){
    await page.evaluate(t=>__s.render(t),i/FPS);
    const buf=await page.screenshot({type:'jpeg',quality:90});
    if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
  }
  ff.stdin.end();await done;fs.unlinkSync(wf);return seg;
}

(async()=>{
  const t0=Date.now();const queue=[...questions];let done=0;
  const b=await chromium.launch();
  await Promise.all(Array.from({length:workers},async()=>{
    const page=await b.newPage({viewport:{width:1280,height:720}});
    page.on('pageerror',e=>console.log('PAGE ERROR',e.message));
    await page.goto('file://'+path.join(__dirname,'scene.html'));await page.waitForTimeout(300);
    for(let q;(q=queue.shift());){await renderOne(page,q);done++;process.stdout.write(`\r${done}/${questions.length} questions  ${Math.round((Date.now()-t0)/1000)}s`)}
  }));
  await b.close();
  const list=questions.map(q=>`file '${path.join(tmp,`seg_${String(q.n).padStart(3,'0')}.mp4`)}'`).join('\n');
  fs.writeFileSync(path.join(tmp,'list.txt'),list);
  execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i',path.join(tmp,'list.txt'),'-c','copy','-movflags','+faststart',out]);
  fs.rmSync(tmp,{recursive:true,force:true});
  console.log(`\nDone -> ${out}  (${Math.round((Date.now()-t0)/1000)}s)`);
})();
